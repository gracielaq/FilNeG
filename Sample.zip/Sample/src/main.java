import java.io.IOException;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;
public class main {
	public static void main(String[] args) throws IOException, ClassNotFoundException{
		
		//Initialize the tagger
		MaxentTagger tagger = new MaxentTagger("taggers/bidirectional-distsim-wsj-0-18.tagger");
		
		//The sample string
		String sample="The Quick Brown Fox jumps over the lazy dog";
		
		//The tagged string
		String tagged=tagger.tagString(sample);
		
		String[] split=tagged.split(" ");
		//Output the result
		//System.out.println(tagged);
		System.out.println(split[1]);
		
	}
}
